# Cosy And Safe - Application Web

Cette application aide les utilisateurs à identifier leurs besoins informatiques via un formulaire intelligent (wizard) avec IA.

## Structure du projet
- **frontend/** : Application React avec Tailwind CSS
- **backend/** : API Node.js avec PostgreSQL et OpenAI

## Installation
Consultez le fichier `Installation_CosyAndSafe_Documentation.txt` pour les étapes d’installation.

## Technologies
- React + Vite + Tailwind
- Node.js + Express + PostgreSQL
- OpenAI GPT-4 API